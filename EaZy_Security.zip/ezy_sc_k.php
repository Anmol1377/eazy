<?php
$key = 'mysecretkey';
?>