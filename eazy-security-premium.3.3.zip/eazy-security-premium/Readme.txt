=== EaZy Security ===
Requires at least 6.00
Tested up to 6.4
Requires PHP 8
Stable tag Stable
License All private to Bikswee Solutions

EaZy Security is a powerful website security app

== Description ==
EaZy Security is a powerful website security app that will protect your website from hackers, attacks and other threats. It will protect your website from SQLi Attacks (SQL Injection), XSS Vulnerabilities, Proxy Visitors, VPN Visitors, TOR Visitors, Spam and many other types of threats.

== Changelog ==
Updated version 3.3 